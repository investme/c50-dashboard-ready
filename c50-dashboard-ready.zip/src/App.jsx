import React from 'react'
import C50LiveDashboard from './C50LiveDashboard'
export default function App(){return <C50LiveDashboard/>}
