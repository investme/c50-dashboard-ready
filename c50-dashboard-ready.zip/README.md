
# C50 Dashboard - Ready

This is a Vite + React + Tailwind + Recharts demo for the C50 Dashboard (Organic theme).

## Quick start (local)
1. npm install
2. npm run dev
3. Open http://localhost:5173

## Vercel deploy
1. Push this repo to GitHub.
2. Import to Vercel and set Root Directory to the repo root (Vite auto-detects).
3. Add Environment Variable (optional):
   - VITE_API_BASE_URL = https://<your-backend-url>

## Notes
- Growth simulation updates every 3 seconds (medium speed).
- To connect to the backend, deploy the backend and set VITE_API_BASE_URL, then rebuild the frontend.
